Don't change things here, this is a copy of https://github.com/lazka/senf
